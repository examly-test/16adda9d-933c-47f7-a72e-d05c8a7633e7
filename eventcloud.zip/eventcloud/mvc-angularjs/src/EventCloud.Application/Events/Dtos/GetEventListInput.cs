﻿namespace EventCloud.Events.Dtos
{
    public class GetEventListInput
    {
        public bool IncludeCanceledEvents { get; set; }
    }
}