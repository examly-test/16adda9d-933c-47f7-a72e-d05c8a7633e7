namespace EventCloud.Web.Navigation
{
    public static class AppPageNames
    {
        public const string Events = "Events";
        public const string About = "About";
    }
}