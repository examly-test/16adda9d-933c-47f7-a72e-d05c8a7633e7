﻿namespace EventCloud
{
    public class EventCloudConsts
    {
        public const string LocalizationSourceName = "EventCloud";

        public const string ConnectionStringName = "Default";

        public const bool MultiTenancyEnabled = true;
    }
}
